<!DOCTYPE html>
<html>
<head>
	<title>Forget Password </title>
</head>
<body>
HI <br>

 Change Your Password <a href="http://localhost:3000/reset/password/<?php echo e($data); ?>">Click Here</a>
 <br>
 Pincode : <?php echo e($data); ?>



</body>
</html>
<?php /**PATH E:\FirstProDevelopment\ARAdmin\AREcomAdmin\resources\views/mail/forget.blade.php ENDPATH**/ ?>