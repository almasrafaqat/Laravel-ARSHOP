<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Visitor;
// use Location;
use Stevebauman\Location\Facades\Location;


class UserLocationController extends Controller
{
    public function GetVisitorDetails(){

        //$ip_address = $_SERVER['REMOTE_ADDR'];
        // $ip = "188.54.51.24";
        $ip = request()->ip();
        $userLocation = Location::get($ip);
        

        // return $ip;


      
        date_default_timezone_set("Asia/Riyadh");
        $visit_time = date("h:i:sa");
        $visit_date = date("d-m-Y");

        $result = Visitor::insert([
            'ip_address'    => $ip,
            'country'       => $userLocation->countryName,
            'city'          => $userLocation->cityName,
            'visit_time'    => $visit_time,
            'visit_date'    => $visit_date,
        ]);

        return $result;
    }
}
